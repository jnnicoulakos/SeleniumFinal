package pom;

import java.lang.System.Logger;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class Login {
	private WebDriver driver;
	  
	
	// email login
	@FindBy(id = "email")
	WebElement emailLogin;
	
	
	// email login
	@FindBy(id = "password")
	WebElement emailPassword;	
	
	
	// Button Login
	@FindBy(xpath = "//input[@data-test='login-submit']")
	WebElement btnLogin;
	
	
	// email warning
	@FindBy(id = "email-error")
	WebElement emailError;
	
	
	// pass waring
	@FindBy(id = "password-error")
	WebElement 	passError;
	
	// //a[@routerlink='/auth/login']
	@FindBy(xpath = "//a[@routerlink='/auth/login']")
	WebElement 	lnkSignOn;
	
	
	// data-test="nav-favorites"
	@FindBy(xpath = "//a[@routerlink='favorites']")
	WebElement myFavorite;
	
	// Profile
	@FindBy(xpath = "//a[@routerlink='profile']")
	WebElement myProfile;

	
	
	// invoices
	@FindBy(xpath = "//a[@routerlink='invoices']")
	WebElement myInvoices;
	
	//  Messages
	@FindBy(xpath = "//a[@routerlink='messages']")
	WebElement myMessages;
	
	
	// Header item Rentals
	@FindBy(xpath = "//h1[@data-test='page-title']")
	WebElement headerItemOne;	
	
	// //div[@aria-live='assertive']
	@FindBy(xpath = "//div[@class='help-block']")
	WebElement errorText;	
	
	// //h1[@data-test='page-title']
	@FindBy(xpath = "//h1[@data-test='page-title']")
	WebElement landingPageHeader;
	
	
	// Invalid 
	@FindBy(xpath = "//div[@data-test='login-error']/div")
	WebElement loginError;
	
	
	
	// Constructor
	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
		
	}
	
	
	
	// enter email login
	public void enterPass(String pass) {
		emailPassword.clear();
		emailPassword.sendKeys(pass);
	}
	
	

	
	
	
	// Click login
	public void clickLogin() {
		emailPassword.clear();
	}
	
	public String getEmailError() {
		return emailError.getText();
	}
	
	
	public String gerMyUrl() {
		return driver.getCurrentUrl();
	}
	
	public String getMyTitle() {
		return driver.getTitle();
	}
	
	
	
	
	public void enterEmail(String username) {
		emailLogin.clear();
		emailLogin.sendKeys(username);
	}
	
	public void enterPassword(String password) {
		emailPassword.clear();
		emailPassword.sendKeys(password);
	}
	
	public void clickLoginBtn() {
		btnLogin.click();
	}
	
	
	public void verifiedLoginLanding() {
	    
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(60L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class);  
		
		// landingPageHeader

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		System.out.println("URL: " + driver.getCurrentUrl());
		System.out.println("Title: " + driver.getTitle());
		System.out.println("header: " + landingPageHeader.getText());
		
		
		
		Assert.assertTrue(landingPageHeader.getText().contains("My account"), "The header does not match:" + landingPageHeader.getText());
	
		
	}
	/*
	Error: Invalid email or password
	
	Lock out Error: Account locked, too many failed attempts. Please contact the administrator.
	*/
	public void grabLoginError() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		System.out.println("URL: " + driver.getCurrentUrl());
		System.out.println("Title: " + driver.getTitle());
				
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		System.out.println("Error: |" + loginError.getText() + "|");
		System.out.println("Error member ran.");
		
		
		assert(!loginError.getText().isEmpty());
		
		
		
	}
	
	



	public void loginWithCredentials(String username, String password) {
		lnkSignOn.click();		
		enterEmail(username);
		enterPassword(password);
		btnLogin.click();
		
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class);  
	}
	
	
	

}
