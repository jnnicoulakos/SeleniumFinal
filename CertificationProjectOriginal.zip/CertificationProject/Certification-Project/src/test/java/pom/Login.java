package pom;

import java.lang.System.Logger;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class Login {
	private WebDriver driver;
	  
	
	// email login
	@FindBy(id = "email")
	WebElement emailLogin;
	
	
	// email login
	@FindBy(id = "password")
	WebElement emailPassword;	
	
	
	// Button Login
	@FindBy(xpath = "//input[@data-test='login-submit']")
	WebElement btnLogin;
	
	
	// email warning
	@FindBy(id = "email-error")
	WebElement emailError;
	
	
	// pass waring
	@FindBy(id = "password-error")
	WebElement 	passError;
	
	// //a[@routerlink='/auth/login']
	@FindBy(xpath = "//a[@routerlink='/auth/login']")
	WebElement 	lnkSignOn;
	
	
	// data-test="nav-favorites"
	@FindBy(xpath = "//a[@routerlink='favorites']")
	WebElement myFavorite;
	
	// Profile
	@FindBy(xpath = "//a[@routerlink='profile']")
	WebElement myProfile;

	
	
	// invoices
	@FindBy(xpath = "//a[@routerlink='invoices']")
	WebElement myInvoices;
	
	//  Messages
	@FindBy(xpath = "//a[@routerlink='messages']")
	WebElement myMessages;
	
	
	// Header item Rentals
	@FindBy(xpath = "//h1[@data-test='page-title']")
	WebElement headerItemOne;	
	
	// //div[@aria-live='assertive']
	@FindBy(xpath = "//div[@class='help-block']")
	WebElement errorText;	
	
	
	
	
	// Constructor
	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
		
	}
	
	// enter email login
	public void enterEmail(String email) {
		emailLogin.clear();
		emailLogin.sendKeys(email);
	}
	
	// enter email login
	public void enterPass(String pass) {
		emailPassword.clear();
		emailPassword.sendKeys(pass);
	}
	
	

	
	
	
	// Click login
	public void clickLogin() {
		emailPassword.clear();
	}
	
	public String getEmailError() {
		return emailError.getText();
	}
	
	
	public String gerMyUrl() {
		return driver.getCurrentUrl();
	}
	
	public String getMyTitle() {
		return driver.getTitle();
	}
	
	
	
	
	public void loginToSystem(String email, String pass) {
		lnkSignOn.click();
		enterEmail(email);
		enterPass(pass);
		btnLogin.click();
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
			
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  System.out.println("XXXX URL: " + driver.getCurrentUrl());
		  System.out.println("XXXX Title: " + driver.getTitle());
		
		
		
		
		myFavorite.click();
		System.out.println("my Favorite clicked");
		
		System.out.println("*************************");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");

		Assert.assertTrue(driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText().equals("Favorites"), "The header does not match:" + headerItemOne.getText());
		
	}

	
	public void loginToSystemBad(String email, String pass) {
		lnkSignOn.click();
		enterEmail(email);
		enterPass(pass);
		btnLogin.click();
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
			
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  System.out.println("XXXX URL: " + driver.getCurrentUrl());
		  System.out.println("XXXX Title: " + driver.getTitle());
		
		
		

		
		System.out.println("message: " + errorText.getText());
		
		
		

		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='help-block']")).getText().equals("Invalid email or password"), "The header does not match:" + errorText.getText());
		
	}
	
	
	
	public void loginToSystemProfile(String email, String pass) throws InterruptedException {
		lnkSignOn.click();
		enterEmail(email);
		enterPass(pass);
		btnLogin.click();
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  System.out.println("XXXX URL: " + driver.getCurrentUrl());
		  System.out.println("XXXX Title: " + driver.getTitle());
	
		 myProfile.click();
		System.out.println("my Profile clicked");
	}
	
	// invoices
	public void loginToSystemInvoices(String email, String pass) throws InterruptedException {
		lnkSignOn.click();
		enterEmail(email);
		enterPass(pass);
		btnLogin.click();
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  System.out.println("XXXX URL: " + driver.getCurrentUrl());
		  System.out.println("XXXX Title: " + driver.getTitle());
	
		  myInvoices.click();
		System.out.println("my Invoices clicked");
	}	
	
	//  Messages	
	public void loginToSystemMessages(String email, String pass) throws InterruptedException {
		lnkSignOn.click();
		enterEmail(email);
		enterPass(pass);
		btnLogin.click();
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  System.out.println("XXXX URL: " + driver.getCurrentUrl());
		  System.out.println("XXXX Title: " + driver.getTitle());
	
		  myMessages.click();
		System.out.println("my Messages clicked");
	}	
	
	
	
	
	

}
