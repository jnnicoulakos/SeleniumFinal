package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class CatMenu {
	private WebDriver driver;
	
	
	
	@FindBy(xpath = "//a[text()=' Categories ']")
	WebElement menuCategories;
	
	
	
	// menu item Hand Tools
	@FindBy(linkText = "Hand Tools")
	WebElement menuItemHandTool;
	
	
	// menu item Power Tool
	@FindBy(linkText = "Power Tools")
	WebElement menuItemPowerTool;	
	
	// menu item Other
	@FindBy(linkText = "Other")
	WebElement menuItemOther;		
	
	// menu item Special Tools
	@FindBy(linkText = "Special Tools")
	WebElement menuItemSpecialTools;	
	
	// menu item Rentals
	@FindBy(linkText = "Rentals")
	WebElement menuItemRentals;		
	
	// Header Hand Tools
	@FindBy(xpath = "//h2[@data-test='page-title']")
	WebElement headerItemHandTool;
	
	// Header Power Tool
	@FindBy(xpath = "//h2[@data-test='page-title']")
	WebElement headerItemPowerTool;		
	
	// Header Other
	@FindBy(xpath = "//h2[@data-test='page-title']")
	WebElement headerItemOther;		
	
	// Header item Special Tools
	@FindBy(xpath = "//h2[@data-test='page-title']")
	WebElement headerItemSpecialTools;		
	
	// Header item Rentals
	@FindBy(xpath = "//h1[@data-test='page-title']")
	WebElement headerItemRentals;		
	
	public CatMenu(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	
	/*
	Menu Items / test the header when selected. 
		Hand Tools - 
		Power Tools - 
		Other - 
		Special Tools - 
		Rentals - 
	
	
	
	*/
	// Select Hand Tool with header string test.
	public void selectHandTool() {
		// select main menu item
		menuCategories.click();
		// wait for the drop down
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("dropdown-menu")));
		// click the menu item
		menuItemHandTool.click();

		// Wait for element to be visable
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement visibleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-test='page-title']")));
		
		// click on visible item
		visibleElement.click();
		
		System.out.println("*************************");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h2[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");
		
		Assert.assertTrue(headerItemHandTool.getText().equals("Category: Hand Tools"), "The header does not match:" + headerItemHandTool.getText());
		
	}
	
	
	public void selectPowerTools() {
		// select main menu item
		menuCategories.click();
		// wait for the drop down
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("dropdown-menu")));
		// click the menu item
		this.menuItemPowerTool.click();

		// Wait for element to be visable
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement visibleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-test='page-title']")));
		
		// click on visible item
		visibleElement.click();
		
		System.out.println("*************************");
		System.out.println("test Power Tools");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h2[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");
		
		Assert.assertTrue(headerItemHandTool.getText().equals("Category: Power Tools"), "The header does not match:" + headerItemHandTool.getText());
		
		
		
	}
	
	public void selectOther() {
		// select main menu item
		menuCategories.click();
		// wait for the drop down
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("dropdown-menu")));
		// click the menu item
		this.menuItemOther.click();

		// Wait for element to be visable
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement visibleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-test='page-title']")));
		
		// click on visible item
		visibleElement.click();
		
		System.out.println("*************************");
		System.out.println("Other");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h2[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");
		
		Assert.assertTrue(headerItemHandTool.getText().equals("Category: Other"), "The header does not match:" + headerItemHandTool.getText());
		
		
		
	}
	
	public void selectSpecialTools() {
		// select main menu item
		menuCategories.click();
		// wait for the drop down
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("dropdown-menu")));
		// click the menu item
		this.menuItemSpecialTools.click();

		// Wait for element to be visable
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement visibleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-test='page-title']")));
		
		// click on visible item
		visibleElement.click();
		
		System.out.println("*************************");
		System.out.println("Other");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h2[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");
		
		Assert.assertTrue(headerItemHandTool.getText().equals("Category: Special Tools"), "The header does not match:" + headerItemHandTool.getText());
		
		
		
	}
	
	
	public void selectRentals() {
		// select main menu item
		menuCategories.click();
		// wait for the drop down
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("dropdown-menu")));
		// click the menu item
		this.menuItemRentals.click();

		// Wait for element to be visable
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement visibleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@data-test='page-title']")));
		
		// click on visible item
		visibleElement.click();
		
		System.out.println("*************************");
		System.out.println("Rentals");
		System.out.println("Page header:  |" + driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText()+"|");
		System.out.println("*************************");
		
		Assert.assertTrue(driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText().equals("Rentals"), "The header does not match:" + headerItemRentals.getText());
		
		
		
	}

}
