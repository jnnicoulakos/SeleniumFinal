package test;

import org.testng.annotations.Test;

import pom.CatMenu;
import pom.Login;
import utils.Common;

import org.testng.annotations.BeforeMethod;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.AfterMethod;

public class Categories {
  // Testing Smoke test - navigating to all Categories
	  public WebDriver driver; 
	  public Common common;
	  public String browser = "firefox";
	  public String url = "https://practicesoftwaretesting.com/#/";
	  public Login myLogin;	
	
	
	
  // Hand Tools - 
  @Test
  public void testHandTools() {
	  System.out.println("testHandTools Methods");
	  System.out.println("Before Methods");
	  CatMenu  myCatMenu = new CatMenu(driver);	  
	  
	  myCatMenu.selectHandTool();
	  
	  
	  
  }
  
  // Power Tools - 
  @Test
  public void testPowerTools() {
	  System.out.println("testHandTools Methods");
	  System.out.println("Before Methods");
	  CatMenu  myCatMenu = new CatMenu(driver);	  
	  
	  myCatMenu.selectPowerTools();
  } 
  
  
  // Power Tools - 
  @Test
  public void testOther() {
	  System.out.println("testHandTools Methods");
	  System.out.println("Before Methods");
	  CatMenu  myCatMenu = new CatMenu(driver);	  
	  
	  myCatMenu.selectOther();
  }   
  
  
  
	// Special Tools - 
  @Test
  public void testSpecialTools() {
	  System.out.println("testHandTools Methods");
	  System.out.println("Before Methods");
	  CatMenu  myCatMenu = new CatMenu(driver);	  
	  
	  myCatMenu.selectSpecialTools();
  }   	
  
  
  
  
    // Rentals - 
  @Test
  public void testRentals() {
	  System.out.println("testHandTools Methods");
	  System.out.println("Before Methods");
	  CatMenu  myCatMenu = new CatMenu(driver);	  
	  
	  myCatMenu.selectRentals();
  }    
  
  
  
  
  
  
  
  
  
  @BeforeMethod
  public void beforeMethod() {
  	  System.out.println("Before Methods");
	// open the browser and url
	System.out.println("BaseTest before test");
	common = new Common();
	common.setupBrowser(browser, url);
	Wait<WebDriver> wait = new FluentWait<>(driver)
		    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
		    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
		    .ignoring(NoSuchElementException.class);  
	
	
	driver = common.getBrowser();
	  
	  
	  
	  
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("After Methods");
	  common.quitBrowser();
	  
	  
  }

}
