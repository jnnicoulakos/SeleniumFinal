package test;

import org.testng.annotations.Test;

import pom.Login;
import utils.Common;

import org.testng.annotations.BeforeMethod;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;

public class NewTest {
	  public WebDriver driver; 
	  public Common common;
	  public String browser = "firefox";
	  public String url = "https://practicesoftwaretesting.com/#/";
	  public Login myLogin;
	
  @Test
  public void justLogin() throws InterruptedException {
	  System.out.println("justLogin Methods");
	  myLogin = new Login(driver);
	  myLogin.loginToSystem("customer@practicesoftwaretesting.com", "welcome01");
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class); 
		
		
		String myHeader = driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText();
		System.out.println("Header value: " + myHeader);
  
		if(myHeader.contains("Favorites")) {
			System.out.println("Header value: " + myHeader);
			System.out.println("Header Matches");
		} else {
			System.out.println("Header value: " + myHeader);
			System.out.println("Header not Matching " + myHeader);
		}
  
  }
  
  
  // login to profile. "Profile"
  @Test
  public void loginToSystemProfile() throws InterruptedException {
	  System.out.println("justLogin Methods");
	  myLogin = new Login(driver);
	  myLogin.loginToSystemProfile("customer@practicesoftwaretesting.com", "welcome01");
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class); 
		
		
		String myHeader = driver.findElement(By.xpath("//div[@class='row']")).getText();
		System.out.println("Header value: " + myHeader);
  
		if(myHeader.contains("Profile")) {
			System.out.println("Header Profile value: " + myHeader);
			System.out.println("Header Profile Matches");
		} else {
			System.out.println("Header Profile value: " + myHeader);
			System.out.println("Header Profile not Matching " + myHeader);
		}
  
  }  
  
  
  
  
  
  
  
  
  // login to profile. "Profile"
  @Test
  public void loginToSystemInvoices() throws InterruptedException {
	  System.out.println("justLogin Methods");
	  myLogin = new Login(driver);
	  myLogin.loginToSystemInvoices("customer@practicesoftwaretesting.com", "welcome01");
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class); 
		
		
		String myHeader = driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText();
		System.out.println("Header value: " + myHeader);
  
		if(myHeader.contains("Invoices")) {
			System.out.println("Header Invoices value: " + myHeader);
			System.out.println("Header Invoices Matches");
		} else {
			System.out.println("Header Invoices value: " + myHeader);
			System.out.println("Header Invoices not Matching " + myHeader);
		}
  
  }  
  
  
  // login to profile. "Profile"
  @Test
  public void loginToSystemMessages() throws InterruptedException {
	  System.out.println("justLogin Methods");
	  myLogin = new Login(driver);
	  myLogin.loginToSystemMessages("customer@practicesoftwaretesting.com", "welcome01");
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class); 
		
		
		String myHeader = driver.findElement(By.xpath("//h1[@data-test='page-title']")).getText();
		System.out.println("Header value: " + myHeader);
  
		if(myHeader.contains("Messages")) {
			System.out.println("Header Messages value: " + myHeader);
			System.out.println("Header Messages Matches");
		} else {
			System.out.println("Header Messages value: " + myHeader);
			System.out.println("Header Messages not Matching " + myHeader);
		}
  
  }  
  
  
  
  @BeforeMethod
  public void beforeMethod() {
	  	  System.out.println("Before Methods");
		// open the browser and url
		System.out.println("BaseTest before test");
		common = new Common();
		common.setupBrowser(browser, url);
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class);  
		
		
		driver = common.getBrowser();
	  
	  
	  
  }

  
  
  
  @AfterMethod
  public void afterMethod() {
	  System.out.println("After Methods"); 
	  common.quitBrowser();
	  
	  
  }

  
  
  
  
  
  
  
  
}
