package org.edureka.cucumber_Cert_Project;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.en.*;
import pom.Login;
import utils.Common;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Assertions.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;


public class StepDefinitions {

	
	
	  public WebDriver driver; 
	  public Common common;
	  public String browser = "firefox";
	  public String url = "https://practicesoftwaretesting.com/#/";
	  public Login myLogin;	
	  
	  
	  @Before
	  public void beforeMethod() {
	  	  System.out.println("Before Methods");
		// open the browser and url
		System.out.println("BaseTest before test");
		common = new Common();
		common.setupBrowser(browser, url);
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class);  
		
		
		driver = common.getBrowser();
		myLogin = new Login(driver);  
		  
		  
		  
	  }

	  @After
	  public void afterMethod() {
		  System.out.println("After Methods");
		  common.quitBrowser();
		  
		  
	  }
	
	
	
	
	
	
	
    @Given("an example scenario")
    public void anExampleScenario() {
    	System.out.println("************************************************************");
    	System.out.println("anExampleScenario ran");
    	System.out.println("************************************************************");
    	
    	
    	
    }

    @When("all step definitions are implemented")
    public void allStepDefinitionsAreImplemented() {
    	System.out.println("************************************************************");
    	System.out.println("allStepDefinitionsAreImplemented ran");
    	System.out.println("************************************************************");
    	
    	
    	
    }

    @Then("the scenario passes")
    public void theScenarioPasses() {
    	System.out.println("************************************************************");
    	System.out.println("theScenarioPasses ran");
    	System.out.println("************************************************************");
    }

    @Given("login to site valid login")
    public void login_to_site_valid_login() {
        // Write code here that turns the phrase above into concrete actions
        // throw new io.cucumber.java.PendingException();
    	driver.navigate().to(url);
    	myLogin.loginWithCredentials("customer@practicesoftwaretesting.com", "welcome01");

    }

    @Then("Landing page appears")
    public void landing_page_appears() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
               myLogin.verifiedLoginLanding();
        
        
    }

    @Given("login to site invalid login")
    public void login_to_site_invalid_login() {
        // Write code here that turns the phrase above into concrete actions
        // throw new io.cucumber.java.PendingException();
    	driver.navigate().to(url);
    	myLogin.loginWithCredentials("customer@practicesoftwaretesting.com", "xxxx");
    }

    @Then("login error appears")
    public void login_error_appears() {
        // Write code here that turns the phrase above into concrete actions
        // throw new io.cucumber.java.PendingException();
    	myLogin.grabLoginError();

        
    }
    

    
    
}
