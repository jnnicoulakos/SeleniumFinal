package org.edureka.cucumber_Cert_Project;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pom.CatMenu;
import pom.Login;
import utils.Common;

public class CategoryMenuTestDefinitions {
	
	
	  public WebDriver driver; 
	  public Common common;
	  public String browser = "firefox";
	  public String url = "https://practicesoftwaretesting.com/#/";
	  public Login myLogin;	
	  public CatMenu myCatMenu;
	  
	  @Before
	  public void beforeMethod() {
	  	  System.out.println("Before Methods");
		// open the browser and url
		System.out.println("BaseTest before test");
		common = new Common();
		common.setupBrowser(browser, url);
		Wait<WebDriver> wait = new FluentWait<>(driver)
			    .withTimeout(Duration.ofSeconds(30L)) // Timeout time
			    .pollingEvery(Duration.ofSeconds(5L)) // Interval 5 seconds
			    .ignoring(NoSuchElementException.class);  
		
		
		driver = common.getBrowser();
		myLogin = new Login(driver);  
		myCatMenu = new CatMenu(driver); 
		  
		  
	  }

	  @After
	  public void afterMethod() {
		  System.out.println("After Methods");
		  common.quitBrowser();
		  
		  
	  }
	
	
	  /*    
	    Tool shop Category testing, verifying that the Category menu navigates to the menu items. 
		Menu Items / test the header when selected. 
			Hand Tools - 
			Power Tools - 
			Other - 
			Special Tools - 
			Rentals - 

	    
	*/    
	    @Given("Landing on the Tool shop home page")
	    public void landing_on_the_tool_shop_home_page() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	// common.setupBrowser(browser, url);
	    	System.out.println("Url now: "   +    driver.getCurrentUrl());
	    	
	    	
	    }

	    @Then("Validate the Tool shop Category Hand Tools")
	    public void validate_the_tool_shop_category_hand_tools() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	System.out.println("Validate the Tool shop Category Hand Tools");
	    	myCatMenu.selectHandTool();
	    	
	    	
	    }

	    @Then("Validate the Tool shop Category Power Tools")
	    public void validate_the_tool_shop_category_power_tools() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	// System.out.println("Validate the Tool shop Category Hand Tools");
	    	myCatMenu.selectPowerTools();
	    	
	    	
	    }

	    @Then("Validate the Tool shop Category Other")
	    public void validate_the_tool_shop_category_other() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	// System.out.println("Validate the Tool shop Category Power Tools");
	    	myCatMenu.selectOther();
	    	
	    }

	    @Then("Validate the Tool shop Category Special Tools")
	    public void validate_the_tool_shop_category_special_tools() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	// System.out.println("Validate the Tool shop Category Special Tools");
	    	myCatMenu.selectSpecialTools();
	    	
	    }

	    @Then("Validate the Tool shop Category Rentals")
	    public void validate_the_tool_shop_category_rentals() {
	        // Write code here that turns the phrase above into concrete actions
	        // throw new io.cucumber.java.PendingException();
	    	// System.out.println("Validate the Tool shop Category Rentals");
	    	myCatMenu.selectRentals();
	    	
	    }
	
	
	

}
